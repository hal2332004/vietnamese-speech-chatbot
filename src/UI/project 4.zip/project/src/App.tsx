import React from 'react';
import VoiceChatBot from './components/VoiceChatBot';

function App() {
  return (
    <div className="App">
      <VoiceChatBot />
    </div>
  );
}

export default App;